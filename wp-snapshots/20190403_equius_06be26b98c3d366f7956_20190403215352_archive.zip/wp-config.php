<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'equius');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '(k*Q^]4kcse6g8@8=La|I3e5rQkvTm$)G+,rLPH04h6PIhAr.w*tqVDbz#DYilhe');
define('SECURE_AUTH_KEY',  ';@X8tUBHm#Y_YHN5ogD_F}xjf3EOQb1kz4BS+{>?~:mw4-/A4EH[Z3*9ry;F[6m`');
define('LOGGED_IN_KEY',    'Rv[$y=Px+U5VxpaLy5O58F>1KohT*sHgGLp)V[K2Kd)x!+?7hjR[3K9u-CccW0RU');
define('NONCE_KEY',        '>%:W}P)c`fi 6XHNe+SO%={!1YRE=-,+fMk^k`5)E3vLXOeXf,bB>kj}c@H8#[eG');
define('AUTH_SALT',        'AZl(Db5]sz%bCBtjCpZj8{]O0kGeo^0o}<9sF7GV?KoH#l9LN2F!rFxFpv?Hz0fD');
define('SECURE_AUTH_SALT', ')1Z;MkW7!_B=!3SC,8dBB%eC3n4M~16!bYo[4FV{kt5oFx{iMfv5!r;fFt S((}Z');
define('LOGGED_IN_SALT',   'sk<WJEKh*9a.GjfPxON2-b/G|8HoW<6%+9KNPp)q6-dWph_;WjJp=={hAEux;c/:');
define('NONCE_SALT',       'rSVJDcz*VjN/LqJxwpF9WdRp+[M=z4W:o E2a9eZcEN`mE;HrAc6(_UI >QvLt.w');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

set_time_limit(300);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
